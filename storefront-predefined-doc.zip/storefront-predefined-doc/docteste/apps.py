from django.apps import AppConfig


class DoctesteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'docteste'
