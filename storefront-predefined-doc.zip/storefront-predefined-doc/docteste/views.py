from django.shortcuts import render
from docx import Document
from datetime import datetime
import mysql.connector
from docx2pdf import convert
import os
from django.http import HttpResponse, JsonResponse
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.shortcuts import redirect
from django.http import FileResponse

def home(request):
    conn = mysql.connector.connect(host="localhost", user="root", password="", database="contrato_teste")
    my_cursor = conn.cursor()

    # Buscar todos os usuários da tabela
    tabela_sql = "SELECT id, ut_nome FROM utentes_data"
    my_cursor.execute(tabela_sql)
    usuarios = my_cursor.fetchall()
    
    conn.close()
    
    # Passar a lista de usuários para o template
    return render(request, 'templates.html', {'usuarios': usuarios})

#contrato em nova guia

def exibir_contrato(request, nome_arquivo):
    caminho_arquivo = os.path.join(settings.MEDIA_ROOT, nome_arquivo)
    if os.path.exists(caminho_arquivo):
        return FileResponse(open(caminho_arquivo, 'rb'), content_type='application/pdf')
    else:
        return HttpResponse('Arquivo não encontrado.', status=404)

#gerar contratos especificos

def gerar_contrato_especifico(request):
    if request.method == 'POST':  # Verifica se é um POST
        
        # Verifica se o ID do usuário e o tipo de contrato foram enviados
        user_id = request.POST.get('user_id')
        documento_base = request.POST.get('documento_base')

        if not user_id or not documento_base:
            return JsonResponse({"status": "error", "message": "Selecione um usuário e um tipo de contrato."})
        
        # Caminho onde os arquivos base estão armazenados
        caminho_documento_base = os.path.join(settings.DOCUMENTOS_BASE_DIR, documento_base)
        print(f"Caminho do documento base: {caminho_documento_base}")

        # Verifica se o arquivo de base existe
        if not os.path.exists(caminho_documento_base):
            return JsonResponse({"status": "error", "message": "O documento base selecionado não foi encontrado."})
        

        try:
            # Conectar ao banco de dados
            conn = mysql.connector.connect(host="localhost", user="root", password="", database="contrato_teste")
            my_cursor = conn.cursor()

            # Seleciona os dados do usuário específico usando o ID passado via formulário
            tabela_sql = "SELECT ut_nome, ut_nascimento, ut_endereco FROM utentes_data WHERE id = %s"
            my_cursor.execute(tabela_sql, (user_id,))
            linha = my_cursor.fetchone()  # Busca apenas um resultado

            if not linha:  # Verifica se o usuário foi encontrado
                conn.close()
                return JsonResponse({"status": "error", "message": "Usuário não encontrado."})

            # Extrai os dados do usuário retornado
            ut_nome = linha[0]
            ut_nascimento = linha[1]
            ut_endereco = linha[2]

            # Carrega o documento modelo selecionado pelo usuário
            documento = Document(caminho_documento_base)

            referencias = {
                "NOME": ut_nome,
                "DATA": str(ut_nascimento),
                "ENDERECO": ut_endereco,
            }

            # Substitui os placeholders no documento
            for paragrafo in documento.paragraphs:
                for codigo, valor in referencias.items():
                    paragrafo.text = paragrafo.text.replace(codigo, valor)

            tipo_contrato = documento_base.split('.')[0].replace('contrato_', '')  # Extrai o tipo do contrato
            contrato_nome = f"Contrato-{ut_nome}-{tipo_contrato}.pdf"  # Formato desejado
            contrato_path = os.path.join(settings.MEDIA_ROOT, contrato_nome)

            # Salva o documento gerado
            documento.save(contrato_path.replace('.pdf', '.docx'))

            # Converte para PDF se necessário
            condicao = True  # Define se gera em PDF ou DOCX
            if condicao:
                convert(contrato_path.replace('.pdf', '.docx'))  # Converte o DOCX para PDF
            os.remove(contrato_path.replace('.pdf', '.docx'))  # Remove o arquivo .docx se PDF foi gerado
                
            conn.close()
            return JsonResponse({'status': 'success', 'pdf_url': f'/media/{contrato_nome}'})
        
        except Exception as e:
            print(f"Erro: {str(e)}")
            return JsonResponse({"status": "error", "message": "Erro ao gerar o contrato."})

    return JsonResponse({"status": "error", "message": "Método não permitido."})



